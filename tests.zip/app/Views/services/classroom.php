<!-- Page header -->
<div class="elh-page-header elh-img-bg elh-bg-9">
	<div class="elh-overlay">
		<div class="container text-center">
			<h3 class="elh-page-title">Upcoming Batches</h3>
			<ol class="breadcrumb">
				<li><a href="course_hub.html">Home</a></li>
				<li class="active">Courses</li>
			</ol>
		</div>
	</div>
</div>
<!-- Page header End -->

<!-- Main wrapper start -->
<div class="elh-main-wrap">

	<!-- Course Listing -->
	<div class="elh-section elh-section-padding">
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="row elh-course-listing">
						<h3 style="margin-top: 121px">CLASSROOM TRAINING WILL BE RESUME AFTER COVID-19 LOCKDOWN.</h3>
					</div>
				</div>
				