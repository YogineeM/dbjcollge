<div class="post-1 blog_1">
	<div class="post_1_area blog-area">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 post_left-side">
					<div class="row">
						<div class="col-sm-12">
							<div class="post-img-box">
								<img
									src="<?php echo base_url(); ?>/resources/images/blog/post-02.jpg"
									alt="" class="img-responsive">
							</div>
						</div>
						<div class="col-sm-12">
							<div class="description-content">
								<div class="description-heading">
									<div class="time">
										<span style="font-size: 20px"></span>
									</div>
									<h3>Governing Concile</h3>
								</div>
								<div class="description-text">
									<div class="row">

										<div class="col-sm-11">
											<div class="description-text-right">
												<table class="table table-hover">
													<thead>
														<tr>
															<th>Sr.No</th>
															<th>Name</th>
															<th>Designation</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td><b>Sr. No.</b></td>
															<td><b>Name</b></td>
															<td><b>Designation</b></td>
														</tr>
														<tr>
															<td>1</td>
															<td>Shri. Shridhar Ramchandra Bhide</td>
															<td>President</td>
														</tr>
														<tr>
															<td>2</td>
															<td>Shri. Shriram Narayan Khare</td>
															<td>Vice-President</td>
														</tr>
														<tr>
															<td>3</td>
															<td>Shri. Vishvas Raghunath Chitale</td>
															<td>Vice-President</td>
														</tr>
														<tr>
															<td>4</td>
															<td>Shri. Vijay Vasant Chitale</td>
															<td>Vice-President</td>
														</tr>
														<tr>
															<td>5</td>
															<td>Shri. Prakash Keshav Joshi</td>
															<td>Vice-President</td>
														</tr>
														<tr>
															<td>6</td>
															<td>Shri. Padmakar Ramchandra Bhagvat</td>
															<td>Vice-President</td>
														</tr>
														<tr>
															<td>7</td>
															<td>Shri. Sunil Narayan Bhagavat</td>
															<td>Trustee</td>
														</tr>
														<tr>
															<td>8</td>
															<td>Smt. Nutan Hemkiran Ghag</td>
															<td>Trustee</td>
														</tr>
														<tr>
															<td>9</td>
															<td>Shri. Mahesh Krushnaji Deodhar</td>
															<td>Trustee</td>
														</tr>
														<tr>
															<td>10</td>
															<td>Shri. Mangesh Shrikrushna Tambe</td>
															<td>Chairman</td>
														</tr>
														<tr>
															<td>11</td>
															<td>Adv. Shri. Jeevan Kashinath Relekar</td>
															<td>Vice-Chairman</td>
														</tr>
														<tr>
															<td>12</td>
															<td>Shri. Madhav Bhargav Chitale</td>
															<td>Secretary</td>
														</tr>
														<tr>
															<td>13</td>
															<td>Shri. Dilip Shivaram Kolge</td>
															<td>Joint Secretary</td>
														</tr>
														<tr>
															<td>14</td>
															<td>Shri.Sanjeev Chandrakant Khare</td>
															<td>Treasurer</td>
														</tr>
														<tr>
															<td>15</td>
															<td>Shri. Praksh Maruti Joshi</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>16</td>
															<td>Shri. Suchay Nathuram Redij</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>17</td>
															<td>Shri. Shriram Vishwanath Redij</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>18</td>
															<td>Shri. Atul Vasant Chitale</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>19</td>
															<td>Shri. Liyakat Umar Dalwai</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>20</td>
															<td>Adv. Sau. Pallavi Parag Bhave</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>21</td>
															<td>Shri. Avinash Shrikrushna Joshi</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>22</td>
															<td>Dr. Shri. Vikas Shridhar Natu</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>23</td>
															<td>Dr. Shri. Deepak Prabhakr Vikhare</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>24</td>
															<td>Shri. Nilesh Atmaram Bhuran</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>25</td>
															<td>Shri. Mahendra Madhusudan Kanade</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>26</td>
															<td>Shri. Nityanand Dattatray Bhagvat</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>27</td>
															<td>Dr. Shekhar Jayant Mehendale</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>28</td>
															<td>Shri. Santosh Prabhar Surve</td>
															<td>Member</td>
														</tr>

														<tr>
															<td>29</td>
															<td>Sau. Veda Nayneesh Gudhekar</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>30</td>
															<td>Dr. Shyam Raghunath Joshi</td>
															<td>Member</td>
														</tr>
														<tr>
															<td>31</td>
															<td>Dr.Anagha Uday Gokhale</td>
															<td>Member</td>
														</tr>

													</tbody>
												</table>

											</div>
										</div>
									</div>


								</div>
							</div>
						</div>



						<!--End .row-->



					</div>
				</div>


				<div class="col-sm-4">
					<div class="">
						<div class="blog_side-right">
							<div class="sidebar-content">
								<div class="row">
									<div class="col-sm-12">
										<div class="categories-item">
											<h3>About</h3>
											<ul class="list-unstyled">
												<li><a href="<?php echo base_url();?>/about/nesociety"><i
														class="fa fa-angle-right"></i>NE Society</a></li>
												<li><a
													href="<?php echo base_url();?>/about/governing_council"><i
														class="fa fa-angle-right"></i>Governing Coucil</a></li>
												<li><a
													href="<?php echo base_url();?>/about/message/chairman"><i
														class="fa fa-angle-right"></i>Chairman's Message</a></li>
												<li><a
													href="<?php echo base_url();?>/about/message/principal"><i
														class="fa fa-angle-right"></i>Principal's Message</a></li>
												<li><a href="<?php echo base_url();?>/about/features"><i
														class="fa fa-angle-right"></i>Features</a></li>
												<li><a href="<?php echo base_url();?>/about/perspective"><i
														class="fa fa-angle-right"></i>Perspective Plan </a></li>
											</ul>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12">
										<div class="social-icon">
											<h3>Follow us</h3>
											<div class="row">
												<div class="col-sm-12">
													<ul class="list-unstyled">
														<li><a href="#" class="rss"><i class="fa fa-rss"></i>rss
																feed</a></li>
														<li><a href="#" class="twitter"><i class="fa fa-twitter"></i>Follow
																us</a></li>
														<li><a href="#" class="facebook"><i class="fa fa-facebook"></i>like
																us</a></li>
														<li><a href="#" class="pinterest"><i
																class="fa fa-pinterest"></i>follow us</a></li>
														<li><a href="#" class="instagram"><i
																class="fa fa-instagram"></i>follow us</a></li>
														<li><a href="#" class="google"><i
																class="fa fa-google-plus"></i>plus 1 us</a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>

									<div class="col-sm-12 recent-post-01">
										<h3>Latest Events</h3>
										<div class="row">
											<div class="col-sm-12 recent-single">
												<div class="recent-content-item">
													<div class="img-box">
														<a href="#"><img
															src="<?php echo base_url(); ?>/resources/images/blog/recent-01.jpg"
															alt=""></a>
													</div>
													<div class="recent-text pull-right">
														<a href="#">COVID-19 Safty Awareness Live Broadcast...</a>
														<p>
															22Aug, 2020 <span class="content"><i
																class="fa fa-comments"></i>12</span>
														</p>
													</div>
												</div>
											</div>
											<!-- /.recent-single-item -->

										</div>
									</div>

									<div class="col-sm-12 recent-work">
										<h3>Recent Posts</h3>
										<div class="blog-img-wrapper owl-carousel owl-theme"
											id="bolg-carousel-01" style="opacity: 1; display: block;">
											<div class="owl-wrapper-outer">
												<div class="owl-wrapper"
													style="width: 2160px; left: 0px; display: block;">
													<div class="owl-item" style="width: 360px;">
														<div class="item">
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-01.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-02.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-03.jpg"
																	alt="" class="img-responsive">
															</div>
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-04.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-05.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-06.jpg"
																	alt="" class="img-responsive">
															</div>
														</div>
													</div>
													<div class="owl-item" style="width: 360px;">
														<div class="item">
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-01.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-02.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-03.jpg"
																	alt="" class="img-responsive">
															</div>
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-04.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-05.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-06.jpg"
																	alt="" class="img-responsive">
															</div>
														</div>
													</div>
													<div class="owl-item" style="width: 360px;">
														<div class="item">
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-01.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-02.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-03.jpg"
																	alt="" class="img-responsive">
															</div>
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-04.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-05.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-06.jpg"
																	alt="" class="img-responsive">
															</div>
														</div>
													</div>
												</div>
											</div>




											<div class="owl-controls clickable">
												<div class="owl-buttons">
													<div class="owl-prev">
														<i class="fa fa-angle-left"></i>
													</div>
													<div class="owl-next">
														<i class="fa fa-angle-right"></i>
													</div>
												</div>
											</div>
										</div>
									</div>





								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

