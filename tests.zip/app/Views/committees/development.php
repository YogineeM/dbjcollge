<div class="post-1 blog_1">
	<div class="post_1_area blog-area">
		<div class="container">
			<div class="row">
				<div class="col-sm-8 post_left-side">
					<div class="row">
						<div class="col-sm-12">
							<div class="post-img-box">
								<img
									src="<?php echo base_url(); ?>/resources/images/blog/post-02.jpg"
									alt="" class="img-responsive">
							</div>
						</div>
						<div class="col-sm-12">
							<div class="description-content">
								<div class="description-heading">
									<div class="time">
										<span style="font-size: 20px"></span>
									</div>
									<h3>College Development Committee</h3>
								</div>
								<div class="description-text">
									<div class="row">

										<div class="col-sm-11">
											<div class="description-text-right">
												<ul class="list-unstyled list-services"
													style="padding-left: 40px; font-size: 16px; font-family: 'Roboto', sans-serif; line-height: 40px">
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mr. Mangesh Tambe (Chairman)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mr. Madhav Chitale (Secretary)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mr. Dondiraj Sawant (Local Member)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mrs. Aaradhana Ambre (Local Member)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mr. T. Rehaman (Local Member)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Dr. Shilpa Sapre-Bharmal (IQAC Co-ordinator)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Dr. Madhura Vardhan (Teacher Representative)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mr. Suhas Waghmode (Teacher Representative)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>
														&nbsp; Mr. Gautam Bramhe (Teacher Representative)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light">
													</i>&nbsp; Mr. Anil Kalutaki (Non Teaching Representative)</li>
													<li><i class="fa fa-chevron-circle-right color-gray-light"></i>&nbsp; Dr.
														Shrikrushan Bal (Incharge Principal and Member)</li>
												</ul>

											</div>
										</div>
									</div>


								</div>
							</div>
						</div>



						<!--End .row-->



					</div>
				</div>


				<div class="col-sm-4">
					<div class="">
						<div class="blog_side-right">
							<div class="sidebar-content">
								<div class="row">
									<div class="col-sm-12">
										<div class="categories-item">
											<h3>Quick Links</h3>
											<ul class="list-unstyled">
												<li><a href="<?php echo base_url();?>/naac/introduction"><i
														class="fa fa-angle-right"></i>Introduction</a></li>
												<li><a href="<?php echo base_url();?>/naac/vision"><i
														class="fa fa-angle-right"></i>Vision</a></li>
												<li><a href="<?php echo base_url();?>/naac/objective"><i
														class="fa fa-angle-right"></i>Objective</a></li>
												<li><a href="<?php echo base_url();?>/naac/composition"><i
														class="fa fa-angle-right"></i>Composition</a></li>
												<li><a
													href="<?php echo base_url();?>/naac/operational_features"><i
														class="fa fa-angle-right"></i>Operational Features</a></li>
												<li><a href="<?php echo base_url();?>/naac/aqar"><i
														class="fa fa-angle-right"></i>AQAR </a></li>
												<li><a href="<?php echo base_url();?>/naac/members"><i
														class="fa fa-angle-right"></i>Members </a></li>
												<li><a href="<?php echo base_url();?>/naac/iqac_mom"><i
														class="fa fa-angle-right"></i>IQAC MOM </a></li>
												<li><a href="<?php echo base_url();?>/naac/pso"><i
														class="fa fa-angle-right"></i>PSO </a></li>
												<li><a href="<?php echo base_url();?>/naac/best_practices"><i
														class="fa fa-angle-right"></i>Best Practices </a></li>
												<li><a href="<?php echo base_url();?>/naac/sop"><i
														class="fa fa-angle-right"></i>SOP </a></li>
											</ul>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12">
										<div class="social-icon">
											<h3>Follow us</h3>
											<div class="row">
												<div class="col-sm-12">
													<ul class="list-unstyled">
														<li><a href="#" class="rss"><i class="fa fa-rss"></i>rss
																feed</a></li>
														<li><a href="#" class="twitter"><i class="fa fa-twitter"></i>Follow
																us</a></li>
														<li><a href="#" class="facebook"><i class="fa fa-facebook"></i>like
																us</a></li>
														<li><a href="#" class="pinterest"><i
																class="fa fa-pinterest"></i>follow us</a></li>
														<li><a href="#" class="instagram"><i
																class="fa fa-instagram"></i>follow us</a></li>
														<li><a href="#" class="google"><i
																class="fa fa-google-plus"></i>plus 1 us</a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>

									<div class="col-sm-12 recent-post-01">
										<h3>Latest Events</h3>
										<div class="row">
											<div class="col-sm-12 recent-single">
												<div class="recent-content-item">
													<div class="img-box">
														<a href="#"><img
															src="<?php echo base_url(); ?>/resources/images/blog/recent-01.jpg"
															alt=""></a>
													</div>
													<div class="recent-text pull-right">
														<a href="#">COVID-19 Safty Awareness Live Broadcast...</a>
														<p>
															22Aug, 2020 <span class="content"><i
																class="fa fa-comments"></i>12</span>
														</p>
													</div>
												</div>
											</div>
											<!-- /.recent-single-item -->

										</div>
									</div>

									<div class="col-sm-12 recent-work">
										<h3>Recent Posts</h3>
										<div class="blog-img-wrapper owl-carousel owl-theme"
											id="bolg-carousel-01" style="opacity: 1; display: block;">
											<div class="owl-wrapper-outer">
												<div class="owl-wrapper"
													style="width: 2160px; left: 0px; display: block;">
													<div class="owl-item" style="width: 360px;">
														<div class="item">
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-01.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-02.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-03.jpg"
																	alt="" class="img-responsive">
															</div>
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-04.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-05.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-06.jpg"
																	alt="" class="img-responsive">
															</div>
														</div>
													</div>
													<div class="owl-item" style="width: 360px;">
														<div class="item">
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-01.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-02.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-03.jpg"
																	alt="" class="img-responsive">
															</div>
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-04.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-05.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-06.jpg"
																	alt="" class="img-responsive">
															</div>
														</div>
													</div>
													<div class="owl-item" style="width: 360px;">
														<div class="item">
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-01.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-02.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-03.jpg"
																	alt="" class="img-responsive">
															</div>
															<div class="row-padding-bottom">
																<img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-04.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-05.jpg"
																	alt="" class="img-responsive"> <img
																	src="<?php echo base_url(); ?>/resources/images/blog/recent-work-06.jpg"
																	alt="" class="img-responsive">
															</div>
														</div>
													</div>
												</div>
											</div>




											<div class="owl-controls clickable">
												<div class="owl-buttons">
													<div class="owl-prev">
														<i class="fa fa-angle-left"></i>
													</div>
													<div class="owl-next">
														<i class="fa fa-angle-right"></i>
													</div>
												</div>
											</div>
										</div>
									</div>





								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

