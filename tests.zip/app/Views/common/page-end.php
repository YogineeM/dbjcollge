<!-- ============================
    JavaScript Files
    ============================= -->
    <!-- jQuery -->
	<script src="<?php echo base_url(); ?>/resources/js/vendor/jquery-1.12.4.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="<?php echo base_url(); ?>/resources/js/assets/bootstrap.min.js"></script>
	<!-- Sticky JS -->
	<script src="<?php echo base_url(); ?>/resources/js/assets/jquery.sticky.js"></script>
	<!-- Popup -->
    <script src="<?php echo base_url(); ?>/resources/js/assets/jquery.magnific-popup.min.js"></script>
	<!-- Counter Up -->
    <script src="<?php echo base_url(); ?>/resources/js/assets/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>/resources/js/assets/waypoints.min.js"></script>
 	<!-- owl carousel -->
    <script src="<?php echo base_url(); ?>/resources/js/assets/owl.carousel.min.js"></script>
   <!-- Slick Slider-->
    <script src="<?php echo base_url(); ?>/resources/js/assets/slick.min.js"></script>
    <!-- Main Menu -->
	<script src="<?php echo base_url(); ?>/resources/js/assets/jquery.meanmenu.min.js"></script>
	<!-- Custom JS -->
	<script src="<?php echo base_url(); ?>/resources/js/custom.js"></script>
</body>

</html>