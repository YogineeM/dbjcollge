<?php
namespace App\Models\Com\Atoconn\Contact;

interface ContactDoa
{
    public function createContact($contact,$conn);
    
}

